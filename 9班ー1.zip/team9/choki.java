import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class choki here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class choki extends Actor
{
    /**
     * Act - do whatever the choki wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        getImage().scale( 10, 10 );
    }    
}
